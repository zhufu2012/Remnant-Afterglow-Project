using System;
using Microsoft.Xna.Framework;
using Nez;

namespace SteeringBehaviorsNez.Steering.Behaviors
{
    /// <summary>
    /// 实现“游荡”行为的转向组件。该行为用于使实体在其当前方向上随机改变其路径，以模拟自然的游荡运动。
    /// </summary>
    public class Wander : SteeringComponentBase
    {
        /// <summary>
        /// 圆心距离，表示从实体位置到游荡圆心的距离。
        /// </summary>
        public float CircleDistance { get; set; }

        /// <summary>
        /// 游荡圆的半径，用于确定随机目标点的范围。
        /// </summary>
        public float CircleRadius { get; set; }

        /// <summary>
        /// 当前的游荡角度，用于控制随机目标点的方向。
        /// </summary>
        public float WanderAngle { get; set; }

        /// <summary>
        /// 角度变化范围，用于控制每次更新时角度的最大变化量。
        /// </summary>
        public float AngleChange { get; set; }

        /// <summary>
        /// 构造函数，初始化游荡行为的参数。
        /// </summary>
        /// <param name="circleDistance">圆心距离。</param>
        /// <param name="circleRadius">游荡圆的半径。</param>
        /// <param name="wanderAngle">初始的游荡角度。</param>
        /// <param name="angleChange">每次更新时角度的最大变化量。</param>
        public Wander(float circleDistance, float circleRadius, float wanderAngle, float angleChange)
        {
            if (circleDistance <= 0 || circleRadius <= 0)
                throw new ArgumentException("CircleDistance and CircleRadius must be positive.");

            CircleDistance = circleDistance;
            CircleRadius = circleRadius;
            WanderAngle = wanderAngle;
            AngleChange = angleChange;
        }

        /// <summary>
        /// 初始化方法，设置实体的初始速度和其他属性。
        /// </summary>
        public override void Initialize()
        {
            base.Initialize();

            // 设置一个随机的初始速度向量。
            SteeringEntity.Velocity = Random.RNG.NextVector2(-1, 1).Normalized();
            SteeringEntity.DesiredVelocity = Vector2.Zero;
            SteeringEntity.Steering = Vector2.Zero;
        }

        /// <summary>
        /// 计算并返回游荡行为的转向力。
        /// </summary>
        /// <param name="target">目标对象。</param>
        /// <returns>计算出的转向力。</returns>
        public override Vector2 Steer(ISteeringTarget target)
        {
            if (SteeringEntity == null)
                return Vector2.Zero; // 返回零向量表示没有转向力

            // 计算游荡圆心的位置。
            var circleCenter = SteeringEntity.Velocity.Normalized() * CircleDistance;

            // 计算偏移向量，并根据当前游荡角度进行旋转。
            var displacement = new Vector2(CircleRadius, 0);
            displacement = SetAngle(displacement, WanderAngle);

            // 随机调整游荡角度。
            WanderAngle += Random.RNG.NextFloat(-AngleChange, AngleChange);

            // 计算新的游荡力。
            var wanderForce = circleCenter + displacement;

            // 更新实体的目标速度。
            SteeringEntity.DesiredVelocity = wanderForce.Normalized() * SteeringEntity.MaxVelocity;

            // 计算并返回转向力。
            return SteeringEntity.DesiredVelocity - SteeringEntity.Velocity;
        }

        /// <summary>
        /// 设置向量的角度。
        /// </summary>
        /// <param name="vec">要设置角度的向量。</param>
        /// <param name="value">角度值（以弧度为单位）。</param>
        /// <returns>设置了新角度的向量。</returns>
        private Vector2 SetAngle(Vector2 vec, float value)
        {
            var len = vec.Length();
            vec.X = (float)Math.Cos(value) * len;
            vec.Y = (float)Math.Sin(value) * len;
            return vec;
        }
    }
}